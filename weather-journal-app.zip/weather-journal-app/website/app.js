/* Global Variables */

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = 1 + d.getMonth()+'.'+ d.getDate()+'.'+ d.getFullYear();

// request form 
// "https://api.openweathermap.org/data/2.5/weather?zip={zip code},{country code}&appid={API key}";

// The URL to retrieve weather information from API (U.S. country)
const baseURL = "https://api.openweathermap.org/data/2.5/weather?zip=";

// Personal API Key for OpenWeatherMap API
// units=imperial as required in rubric
const apiKey = ",&appid=01edcb737cb8e864546e5fe785e6f3be&units=imperial";

const generate = document.getElementById('generate');
const zip = document.getElementById('zip');
const feelings = document.getElementById('feelings');
const date = document.getElementById('date');
const temp = document.getElementById('temp');
const content = document.getElementById('content');

/* End Global variables */


// generateData 
// * function to get input values
// * call getWeatherData to fetch the data from API
// * create object from API object by using destructuring
// * post the data in the server
// * get the data to update UI
function generateData(){
    //get values after clicking on the button
    const url = `${baseURL}${zip.value}${apiKey}`;
    console.log("The URL is:", url);
    // fetch the url and get the data from it 
    getWeatherData(url)

    .then ((data)=> {
        const info = processData(data);
    
        postData('/add', info)
    
        .then(()=>{
            updateUi()
        });
    });
};    

//Function to GET Web API Data
const getWeatherData = async (url) =>{
    try {   
        const res = await fetch(url);
            const data = await res.json();
            if(data.cod == 200){
                console.log("Data object:", data)
                return data;
                
            }else{
            console.log("ERROR:", data.message)}
        }
        catch(error) {
        console.log("ERROR:", error.message);
    }
};

// processData function
const processData = (data)=>{

    try{
        if(data.cod != 200){
            return info;
        }
        else{
            const info = {
                date: newDate,
                temp: Math.round(data.main.temp),
                content: feelings.value,
            };
            console.log('Data used:', info);
            return info;
        }
    }catch(error){
        console.log("ERROR:", error);
    }

};

// postData function 
const postData = async (url="", info={}) => {

    const res = await fetch(url, {
        method: "POST",
        credentials:"same-origin",
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(info),
    });

    try {
    const newData = await res.json();
    console.log("You just saved:", newData);
    return newData;
    } 
    catch (error) {
    console.log("ERROR:", error.message);
    }
};

// updateUi
const updateUi = async () => {
    
    const res =await fetch("/all");
    try {
        
    const savedData = await res.json();
        
    date.innerHTML = `Date:${savedData.date}`;
    
    temp.innerHTML = `Teperature:${savedData.temp} &#176` ;
    
    content.innerHTML = `Feeling:${savedData.content}`;

    } catch (error) {
    console.log("ERROR",error);
    }
}

// add Event listener to the existing HTML DOM element
// generat function is called by event listener
generate.addEventListener("click", generateData);